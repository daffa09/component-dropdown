import {
  useState,
  useRef,
  useMemo,
} from "react";
import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import { useClickOutside } from "../hooks/useClickOutside";

type Option = {
  label: string;
  value: string;
};

type Props = {
  options: Option[];
  multi?: boolean;
  searchable?: boolean;
  portal?: boolean;
  renderOption?: (option: Option, selected: boolean) => ReactNode;
  onChange?: (value: Option | Option[]) => void;
};

export default function Dropdown({
  options,
  multi = false,
  searchable = true,
  portal = true,
  renderOption,
  onChange,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Option[]>([]);

  useClickOutside(ref, () => setOpen(false));

  const filtered = useMemo(() => {
    return options.filter((o) =>
      o.label.toLowerCase().includes(query.toLowerCase())
    );
  }, [query, options]);

  function toggle(option: Option) {
    let newValue;

    if (multi) {
      const exists = selected.find((s) => s.value === option.value);
      newValue = exists
        ? selected.filter((s) => s.value !== option.value)
        : [...selected, option];
    } else {
      newValue = [option];
      setOpen(false);
    }

    setSelected(newValue);
    onChange?.(multi ? newValue : newValue[0]);
  }

  const menu = (
    <div className="absolute z-[9999] mt-2 w-full rounded-xl border bg-white shadow-lg">
      {searchable && (
        <input
          className="w-full border-b p-2 outline-none"
          placeholder="Search..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      )}

      <ul className="max-h-60 overflow-auto">
        {filtered.map((opt) => {
          const isSelected = selected.some(
            (s) => s.value === opt.value
          );

          return (
            <li
              key={opt.value}
              onClick={() => toggle(opt)}
              className="cursor-pointer px-3 py-2 hover:bg-gray-100"
            >
              {renderOption
                ? renderOption(opt, isSelected)
                : opt.label}
            </li>
          );
        })}
      </ul>
    </div>
  );

  return (
    <div ref={ref} className="relative w-64">
      <button
        onClick={() => setOpen(!open)}
        className="w-full rounded-xl border p-2 text-left"
      >
        {selected.length
          ? multi
            ? `${selected.length} selected`
            : selected[0].label
          : "Select option"}
      </button>

      {open &&
        (portal
          ? createPortal(menu, document.body)
          : menu)}
    </div>
  );
}
